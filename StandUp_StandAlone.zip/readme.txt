StandUp can be run as a stand-alone executable. The accompaning condiguration file is required to save settings between program starts. Any changed settings will not be saved without the configuration file.

-----

Recent studies suggest that the more people sit each day, the greater their risk for chronic health problems, such as cancer, diabetes and heart disease. Researchers have linked sitting for long periods of time with a number of health concerns, including obesity and metabolic syndrome � a cluster of conditions that includes increased blood pressure, high blood sugar, excess body fat around the waist and abnormal cholesterol levels. 